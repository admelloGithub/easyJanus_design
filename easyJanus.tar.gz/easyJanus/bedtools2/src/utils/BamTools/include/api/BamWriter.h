#include <htslib/sam.h>
#include <vector>
#include <string>
#include <BamAlignment.hpp>
#include <BamWriter.hpp>
