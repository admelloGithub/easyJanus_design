#!/bin/bash

inp=$INP
outdir=$OUT


cp "$inp/input.fasta" "$outdir/input.fasta"
/usr/bin/perl easyJanus_design.pl -t "$inp/targets.txt" -f "$outdir/input.fasta" -o $outdir $1
rm -f $outdir/input.fasta
rm -f $outdir/input.fasta.fai
rm -f $outdir/bed.*






